Universidade do Estado de Santa Catarina \- Centro de Educação Superior do Alto Vale do Itajaí  
Disciplina: Algoritmos e Estrutura de Dados  
Acadêmicos: Lucas Emanoel Gitirana e Marco Antonio Garlini Possamai

**Instruções de Execução**

1. Para executar o sistema, é necessário acessar o arquivo "Sistema.java", que está localizado no pacote *principal* (src\\principal\\Sistema.java).  
   1. A execução pode ser realizada tanto via IDE quanto terminal;

2. Dentro do pacote *principal* há um arquivo chamado "partidas.txt", o qual contém as entradas disponibilizadas no Moodle.   
   1. Durante a execução, o sistema lê o seu conteúdo e simula as partidas com base na sequência de cartas fornecidas. Assim, para alterar ou adicionar novas entradas, basta editá-lo com os valores desejados.

3. A saída do sistema segue o padrão solicitado, estruturado da seguinte forma:  
   1. \<*qtd. de cartas coletadas pelo Jogador 1*\> \<*qtd. de cartas coletadas pelo Jogador 2*\> \<*vencedor ou empate*\>.